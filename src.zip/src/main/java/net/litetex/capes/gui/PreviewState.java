package net.litetex.capes.gui;

public final class PreviewState {
    private PreviewState() {}

    public static volatile boolean hideBodyForPreview = false;

    /** While true, MixinLayerCape always renders the cape itself instead of
     *  deferring to WaveyCapes (or any other mod's own layer). WaveyCapes'
     *  cape uses an independent cloth simulation that our pose-freezing
     *  can't reach, so this sidesteps it entirely just for the preview. */
    public static volatile boolean forceOwnCapeRender = false;
}