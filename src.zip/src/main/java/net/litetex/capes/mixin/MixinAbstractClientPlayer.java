package net.litetex.capes.mixin;

import net.litetex.capes.provider.CapeProviderManager;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayer.class)
public abstract class MixinAbstractClientPlayer {

    /**
     * Real vanilla 1.8.9 method (confirmed via WaveyCapes' own source, which
     * calls this directly): AbstractClientPlayer.getLocationCape().
     * NOT "getLocationOfCape" — that method never existed, which is why
     * the earlier mixin silently failed to apply.
     *
     * No @Shadow field needed — we only need to override the return value.
     */
    @Inject(
        method      = "getLocationCape",
        at          = @At("HEAD"),
        cancellable = true
    )
    private void cpx$getLocationCape(CallbackInfoReturnable<ResourceLocation> cir) {
        CapeProviderManager mgr = CapeProviderManager.getInstance();
        if (mgr == null) return;

        AbstractClientPlayer self = (AbstractClientPlayer)(Object) this;

        mgr.requestCape(self);

        ResourceLocation ourCape = mgr.getCapeTexture(self);
        if (ourCape != null) {
            cir.setReturnValue(ourCape);
        }
    }
}