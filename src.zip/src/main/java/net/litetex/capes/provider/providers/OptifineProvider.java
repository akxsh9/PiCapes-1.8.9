package net.litetex.capes.provider.providers;

import com.mojang.authlib.GameProfile;
import net.litetex.capes.provider.ICapeProvider;

import javax.annotation.Nullable;

public class OptifineProvider implements ICapeProvider {
    @Override public String getId()   { return "optifine"; }
    @Override public String getName() { return "Optifine"; }

    @Override
    @Nullable
    public String getCapeUrl(GameProfile profile) {
        // Optifine uses the player's username. Returns HTTP 404 for non-cape players —
        // CapeTextureLoader will reject non-200 responses automatically.
        return "http://s.optifine.net/capes/" + profile.getName() + ".png";
    }
    
    @Override
    public String getUserAgent() {
        return "CapeProviderX/1.0 Forge/1.8.9";
    }
}