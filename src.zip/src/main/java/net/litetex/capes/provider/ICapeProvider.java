package net.litetex.capes.provider;

import com.mojang.authlib.GameProfile;

public interface ICapeProvider {

    String getId();
    String getName();

    /**
     * Returns the cape texture URL for this player, or null if none.
     */
    String getCapeUrl(GameProfile profile);

    /**
     * Optional: override to supply a custom HTTP User-Agent header
     * for the texture download request.
     * Default is "CapeProviderX/1.0 Forge/1.8.9".
     */
    String getUserAgent();
}